﻿using System.Web.UI;

namespace deskshifts.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}