﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace deskshifts
{
    public partial class LoginPage : System.Web.UI.Page
    {
        public String[] usernames;
       
        protected void Page_Load(object sender, EventArgs e)
        {
            usernames = new String[1];
            usernames[0] = "Cruz";
            
        }

        protected void Submit_Click(object sender, EventArgs e)
        {
            //1st line set new bool to false, 2nd line check if the string entered is in the array, 3rd if it does exist, go to selection page
            bool exists = false;
            exists = Array.Exists(usernames, element => element == "Cruz");
            if (exists) { Response.Redirect("SelectionPage.aspx"); }

            //set the error label to false if the username does not exist
            else { ErrorLabel.Visible = true; }
        }
    }
}