﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace deskshifts
{
    public partial class SelectionPage : System.Web.UI.Page
    {
        string connectionString = "Data Source=deskteam.database.windows.net;Initial Catalog = ShiftDatabase; Integrated Security = False; User ID = cruzbaciewicz; Password=%Thirdevo1102;Connect Timeout = 60; Encrypt=True;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False;";
       
        public string info;
        public int id;

        protected void Page_Load(object sender, EventArgs e)
        {
        
        }


        //This button handles the submission of a shift request
        protected void Button1_Click(object sender, EventArgs e)
        {
            //grab id which has been entered
            id = Convert.ToInt32(TextBox1.Text);

            //use the method getShiftInfo to pull data from database
            info = getShiftInfo(id);
            
          //go to ThankyouPage to use info for email and thank you message
            Response.Redirect("ThankyouPage.aspx");
        }

        protected string getShiftInfo(int idOfShift)
        {
            string shiftInfo = "";

            using (SqlConnection myConnection = new SqlConnection(connectionString))
            {
                myConnection.Open();

                using (SqlCommand command = new SqlCommand())
                {
                    myConnection.Open();
                    command.Connection = myConnection;
                    command.CommandType = CommandType.Text;
                    command.CommandText = "Select * From Shifts Where Id = @idOfShift";
                    command.Parameters.AddWithValue("@idOfShift", idOfShift);
                }
            }

            return shiftInfo;
        }
    }
}